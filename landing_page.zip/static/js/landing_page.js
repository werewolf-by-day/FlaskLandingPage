alert('sup ninja!');
